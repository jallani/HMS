 <div class="ml-5 ">
  <div class="">
   <a href="<?php echo base_url()?>EmployeesList" class="btn btn-primary mb-3  ml-2">out Patient</a>
         <a href="<?php echo base_url()?>Nursingdashboard" class="btn btn-primary mb-3  ml-2">In Patient</a>
         <a href="<?php echo base_url()?>nursingnephrology" class="btn btn-primary mb-3  ml-2">Nephrology</a>
         <a href="<?php echo base_url()?>nursingrequisition" class="btn btn-primary mb-3  ml-2">Requisition List</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn btn-primary mb-3  ml-2">Discharge Summary</a>
       </div>
      </div>


        <div class="ml-4 ">
   <h3 class="text-primary">Nephrology</h3>
        
      </div>
       <div class="iq-search-bar ml-2 mb-4">
                     <form action="#" class="searchbox">
                        <input type="text" class="text search-input" placeholder="Search....">
                        <a class="search-link" href="#"><i class="ri-search-line"></i></a>
                     </form>
                  </div>

       <!-- Table start From here -->

            <div class="container-fluid mt-1">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">

                              <span class="table-add float-right mb-3 mr-2">
                                <a href="" class="btn btn-outline-primary mb-3  ml-2">Print</a>
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr class="bg-primary">
                                     
                                       <th>Patient Name</th>
                                       <th>Phone No.</th>
                                       <th>Age</th>
                                       <th>Sex</th>
                                       <th>Provide Name </th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td class="text-dark">umer</td>
                                       <td contenteditable="true">Assistent</td>
                                       <td contenteditable="true">HR</td>
                                       <td contenteditable="true">00887878</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                

                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->

