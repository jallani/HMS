 <div class="ml-5 ">
  <div class="">
   <a href="<?php echo base_url()?>EmployeesList" class="btn btn-primary mb-3  ml-2">out Patient</a>
         <a href="<?php echo base_url()?>Nursingdashboard" class="btn btn-primary mb-3  ml-2">In Patient</a>
         <a href="<?php echo base_url()?>nursingnephrology" class="btn btn-primary mb-3  ml-2">Nephrology</a>
         <a href="<?php echo base_url()?>nursingrequisition" class="btn btn-primary mb-3  ml-2">Requisition List</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn btn-primary mb-3  ml-2">Discharge Summary</a>
       </div>
      </div>




    <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="iq">
                        <div class="p-0">
                           <div class="iq-edit-list">
                              <ul class="iq-edit-profile d-flex nav nav-pills ">
                                 <li class="col-md-6 p-0">
                                    <a class="nav-link active bg-info" data-toggle="pill" href="#Lama">
                                    Discharge Patient
                                    </a>
                                 </li>
                                 <li class="col-md-6 p-0">
                                    <a class="nav-link bg-warning " data-toggle="pill" href="#Transferred">
                                    Admitted Patient
                                    </a>
                                 </li>
                                
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-12 mt-4">
                     <div class="iq-edit-list-data">
                        <div class="tab-content">
                           <div class="tab-pane fade active show" id="Lama" role="tabpanel">
                              <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h3>Discharge</h3>
                                    </div>
                                 </div>
                                 <div class="iq-card-body">
                                    <!-- Table start From here -->
                                      <div class="row ml-2 mt-2">
    <div class="col-lg-6">
                                                <div class="form-group">
                                                   
                                                   <input type="text" class="form-control"  placeholder="Search" required="required" />
                                                </div>

                                             </div>
                                             <div class="">
                                                <div class="form-group">
                                                   
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">All</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>

                                                </div>
                                             </div>
                                            
                    
                        
                

        
</div>
<!--end  Existing button  -->

                                                    <div class="container-fluid mt-1">
                                                       <div class="row">
                                                          <div class="col-sm-12">
                                                             <div class="iq-card">
                                                                <div class="iq-card-body">
                                                                   <div id="table" class="table-editable">
                                                                      <span class="table-add float-right mb-3 mr-2">
                                                                     
                                                                      </span>
                                                                      <table class="table table-bordered table-responsive-md table-striped text-center">
                                                                         <thead>
                                                                            <tr>
                                                                               <th>Patient Name</th>
                                                                               <th>Contact No.</th>
                                                                               <th>Date</th>
                                                                               <th>Status</th>
                                                                               
                                                                               <th>Action</th>
                                                                               
                                                                            </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                            <tr>
                                                                               <td contenteditable="true">ALi</td>
                                                                               <td contenteditable="true">29 Y</td>
                                                                               <td contenteditable="true">Male</td>
                                                                             <td contenteditable="true">2022-04-28/01:09 PM</td>
                                                                             
                                                                             
                                                                             <td>
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Vitals</button></span>
                                                                                <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Summery</button></span>
                                                                                    
                                                                               </td>
                                                                            </tr>
                                                                          
                                                                            
                                                                            
                                                                         </tbody>
                                                                      </table>
                                                                   </div>
                                                                </div>
                                                             </div>
                                                          </div>
                                                       </div>
                                                    </div>


                                                    <!-- Table End  here -->
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="Transferred" role="tabpanel">
                              <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Admitted Patient</h4>
                                    </div>
                                 </div>
                                 <div class="iq-card-body">
                                    <!-- Table start From here -->
                                      <div class="row ml-2 mt-2">
    <div class="col-lg-6">
                                                <div class="form-group">
                                                   
                                                   <input type="text" class="form-control"  placeholder="Search" required="required" />
                                                </div>

                                             </div>
                                             <div class="">
                                                <div class="form-group">
                                                   
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">All</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>

                                                </div>
                                             </div>
                                              <div class="container-fluid mt-1">
                                                       <div class="row">
                                                          <div class="col-sm-12">
                                                             <div class="iq-card">
                                                                <div class="iq-card-body">
                                                                   <div id="table" class="table-editable">
                                                                      <span class="table-add float-right mb-3 mr-2">
                                                                     
                                                                      </span>
                                                                      <table class="table table-bordered table-responsive-md table-striped text-center">
                                                                         <thead>
                                                                            <tr>
                                                                               <th>Patient Name</th>
                                                                               <th>Contact No.</th>
                                                                               <th>Date</th>
                                                                               <th>Status</th>
                                                                               
                                                                               <th>Action</th>
                                                                               
                                                                            </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                            <tr>
                                                                               <td contenteditable="true">ALi</td>
                                                                               <td contenteditable="true">29 Y</td>
                                                                               <td contenteditable="true">Male</td>
                                                                             <td contenteditable="true">2022-04-28/01:09 PM</td>
                                                                             
                                                                             
                                                                             <td>
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Vitals</button></span>
                                                                                <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Summery</button></span>
                                                                                    
                                                                               </td>
                                                                            </tr>
                                                                          
                                                                            
                                                                            
                                                                         </tbody>
                                                                      </table>
                                                                   </div>
                                                                </div>
                                                             </div>
                                                          </div>
                                                       </div>
                                                    </div>
                                            
                    
                        
                

        
</div>

                                            
                    
                        
                

        
</div>
                        
                

        
</div>
                        
 

                                 </div>

                              </div>
                           </div>
                        </div>
                     </div>
                     <nav aria-label="..." class="float-right">
                              <ul class="pagination">
                                 <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                 </li>
                                 <li class="page-item"><a class="page-link" href="#">1</a></li>
                                 <li class="page-item active" aria-current="page">
                                    <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
                                 </li>
                                 <li class="page-item"><a class="page-link" href="#">3</a></li>
                                 <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                 </li>
                              </ul>
                           </nav>
                  </div>

               </div>

            </div>
