 <div class="ml-5 ">
  <div class="">
   <a href="<?php echo base_url()?>EmployeesList" class="btn btn-primary mb-3  ml-2">out Patient</a>
         <a href="<?php echo base_url()?>Nursingdashboard" class="btn btn-primary mb-3  ml-2">In Patient</a>
         <a href="<?php echo base_url()?>nursingnephrology" class="btn btn-primary mb-3  ml-2">Nephrology</a>
         <a href="<?php echo base_url()?>nursingrequisition" class="btn btn-primary mb-3  ml-2">Requisition List</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn btn-primary mb-3  ml-2">Discharge Summary</a>
       </div>
      </div>