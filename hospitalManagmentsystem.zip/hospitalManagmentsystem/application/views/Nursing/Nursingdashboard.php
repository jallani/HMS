 <div class="ml-5 ">
  <div class="">
   <a href="<?php echo base_url()?>EmployeesList" class="btn btn-primary mb-3  ml-2">out Patient</a>
         <a href="<?php echo base_url()?>Nursingdashboard" class="btn btn-primary mb-3  ml-2">In Patient</a>
         <a href="<?php echo base_url()?>nursingnephrology" class="btn btn-primary mb-3  ml-2">Nephrology</a>
         <a href="<?php echo base_url()?>nursingrequisition" class="btn btn-primary mb-3  ml-2">Requisition List</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn btn-primary mb-3  ml-2">Discharge Summary</a>
       </div>
      </div>
      <div class="ml-4 ">
        <h2 class="text-primary">* Select Your Ward</h2>
      </div>


      <div class="col-lg-12 mt-5">

                     <div class="row">
                     
                        <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="<?php echo base_url()?>nursinginpatient">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  General </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                         <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  ICU </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                         <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  Male Ward </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                         <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  NICU </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                          <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  Pediatric </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                          <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  Female Ward </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                          <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  Post OP </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                          <div class="col-md-4 col-lg-3">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; ">
                                <a href="#">

                                 <div class="d-flex  justify-content-between">
                                  <h3 class="text-primary">
                                   <i class="fa fa-plus-square"></i>  Ward 11 </h3><br>
                                    <div class=""></div>
                                    <div class="text-right"  >                                 
                                       <h2 class="mb-0 text-primary ml-2" ><span class="counter">12</span></h2>
                                       <h6 class="text-primary"><span>Patient</span></h6>
                                       
                                    </div>
                                   
                                    
                                 </div>
                                 <div class="row mt-4">
                                  <div class="col-lg-6">
                                     <p class="text-danger">12 beds</p>
                                     </div>
                                      <div class="col-lg-6">
                                     <p class="float-right text-success">25 beds Vacant</p>
                                   </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                    
                        
                        
                     </div>
 </div>

