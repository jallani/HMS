 <div class="ml-5">
   <a href="<?php echo base_url()?>EmployeesList" class="btn btn-outline-primary mb-3  ml-2">Employee Information</a>
         <a href="<?php echo base_url()?>Helpdeskdashboard" class="btn btn-outline-primary mb-3  ml-2">Bed Information</a>
         <a href="" class="btn btn-outline-primary mb-3  ml-2">Queue Information</a>
      </div>


<div class="col-lg-12 mt-5">
                     <div class="row">
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                  <h4 class="text-white">Total No. OF BED</h4><br>
                                    <div class=""></div>
                                    <div class="text-right"  id="topmarginemg">                                 
                                       <h2 class="mb-0 text-white" ><span class="counter">5600</span></h2>
                                       
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image:linear-gradient(-20deg, #e7505a 0%, #ff825c 100%)">
                                 <div class="d-flex  justify-content-between">
                                  <h4 class="text-white">Available No. OF BED</h4><br>
                                  <div class=""></div>
                                  <br>
                                      <div class="text-right" id="topmarginemg">                                 
                                       <h2 class="mb-0 text-white" ><span class="counter">3450</span></h2>
                                       
                                    </div>
                                    
                                 </div>
                                  
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" 
                              style="height:100%; background-image: linear-gradient(to top, #0773bc 0%, #32c5d2 100%);">
                                 <div class="d-flex  justify-content-between ">
                                   <h4 class="text-white">Occupied No. OF BED</h4>
                                    <div class="text-right mt-7" id="topmarginemg">                                 
                                       <h2 class="mb-0 text-white"><span class="counter">3500</span></h2>
                                      
                                    </div>
                                    
                                 </div>
                                  
                                 
                              </div>
                           </div>
                        </div>
                        
                     </div>
 </div>


  <div class="ml-4 ">
   <h3 class="text-primary">Bed Occupancy Status</h3>
        
      </div>

           <!-- Table start From here -->

            <div class="container-fluid mt-1">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr class="bg-primary">
                                     
                                       <th>Ward Name</th>
                                       <th>Occupied</th>
                                       <th>Vacant</th>
                                       <th>Reserved</th>
                                       <th>Total</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td class="text-dark">Female</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">General</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">ICU</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">Maleward</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">NICU</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">Pediatric</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">Post OP</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-dark">Suit</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>
                                 <tbody>
                                    <tr>
                                       
                                       <td class="text-primary">Total</td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     </tr>
                                     
                                     
                                    
                                    
                                 
                                 </tbody>

                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->








