    <div class="ml-3 mt-2">
               <h3 class="">Operation Theatre</h3>

            </div>
            <div>
               <button type="button" class="btn btn-primary ml-4 mt-3" data-toggle="modal" data-target=".bd-example-modal-xl"> New OT Booking</button>
            </div>
            <div class="iq-search-bar ml-2 mt-2">
                     <form action="#" class="searchbox">
                        <input type="text" class="text search-input" placeholder="Ward/Bed no.">
                        <a class="search-link" href="#"><i class="ri-search-line"></i></a>
                     </form>
                  </div>





                  
                           <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                       <h5 class="modal-title text-white">Booking OT Schedule | New Patient</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Select Patient</label>
                                                         <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select Patient name</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>
                                                      </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>EnterOT Date/Time</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="dob">Diagnosis</label>
                                                   <input type="text" class="form-control"  />
                                                   
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Type of Surgery</label>
                                                   <input type="text" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Procedure *</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Surgeon Name</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Anesthetist Doctor Name</label>
                                                   <input type="text" class="form-control">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Anesthetist Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Anesthesia :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Scrub Nurse :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">OT Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Remarks :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                      
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                       <button type="button" class="btn btn-primary">Add New OT</button>
                                    </div>
                                 </div>
                              </div>
                           </div>



            <!-- Table start From here -->

            <div class="container-fluid mt-3  ">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title" style="width: 100%;">
                              <h4 class="card-title">Patient List
                             
                              <button class="btn btn-primary float-end">Print</button>
                              </h4>
                              
                           </div>
                        </div>
                        <div class="iq-card-body" style="overflow-x: scroll;">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center mr-4">
                                 <thead>
                                    <tr>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Date/Time</th>
                                       <th>Ward/Bed No.</th>
                                       <th>Diagnosis</th>
                                       <th>Surgery Type</th>
                                       <th>Procedure</th>
                                       <th>Surgeon</th>
                                       <th>Anesthsia Doctor</th>
                                       <th>Anesthsia</th>
                                       <th>Anesthsia Assistant</th>
                                       <th>Scrub Nurse</th>
                                       <th>OT Assistant</th>
                                       <th>Remarks</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">2022-11-15T03:27:00</td>
                                       <td contenteditable="true">Other salmonella infections</td>
                                       <td>vxx</td>
                                       <td>xzs</td>
                                       <td>undefined</td>
                                       <td>undefined</td>
                                       <td>aasd</td>
                                       <td>undefined</td>
                                       <td>undefined</td>
                                       <td>undefined</td>
                                       <td>undefined</td>
                                       <td>undefined</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Edit</button></span>
                                       </td>
                                    </tr>

                                 </tbody>
                              </table>
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

 <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                       <h5 class="modal-title text-white">Edit OT Schedule | New Patient</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Select Patient</label>
                                                         <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select Patient name</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>
                                                      </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>EnterOT Date/Time</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="dob">Diagnosis</label>
                                                   <input type="text" class="form-control"  />
                                                   
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Type of Surgery</label>
                                                   <input type="text" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Procedure *</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Surgeon Name</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Anesthetist Doctor Name</label>
                                                   <input type="text" class="form-control">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Anesthetist Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Anesthesia :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Scrub Nurse :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">OT Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Remarks :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                      
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                       <button type="button" class="btn btn-primary">Update OT Detials</button>
                                    </div>
                                 </div>
                              </div>
                           </div>






            <!-- Table End  here -->



