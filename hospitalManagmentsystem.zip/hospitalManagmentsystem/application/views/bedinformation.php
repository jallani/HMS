 <!-- Table start From here -->
 
 <div class="ml-5">
   <a href="<?php echo base_url()?>Emergencydashboard" class="btn btn-outline-primary mb-3  ml-2" ><i class="fa fa-home"  aria-hidden="true"></i></a>
   <a href="<?php echo base_url()?>Emg_new_patients" class="btn btn-outline-primary mb-3  ml-2">New Patient</a>
         <a href="<?php echo base_url()?>Emg_Triage_Patient" class="btn btn-outline-primary mb-3  ml-2">Triaged Patient</a>
         <a href="<?php echo base_url()?>Emp_Finalize_patient" class="btn btn-outline-primary mb-3  ml-2">Finalized Patients</a>
         <a href="<?php echo base_url()?>bedinformation" class="btn btn-outline-primary mb-3  ml-2">Bed Information</a>
      </div>

            <div class="container-fluid mt-1">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">New Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr class="bg-primary">
                                       <th>Bed Feature</th>
                                       <th>Occupied</th>
                                       <th>Vacant</th>
                                       <th>Total</th>
                                       
                                       
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                   
                                    <tr>
                                      <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                       <td contenteditable="true"></td>
                                     
                                     
                                      
                                    </tr>
                                   
                                  
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->