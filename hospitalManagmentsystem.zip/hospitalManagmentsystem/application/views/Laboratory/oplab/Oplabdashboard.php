   <div class="ml-4 mb-3">
      	<h3 class="text-dark font-weight-bold ">OP LAB</h3>
      </div>


 <div class="ml-4 ">
  <div class="">
    <a href="<?php echo base_url()?>samplecollection" class="btn text-white  mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Sample Collection </a>
         <a href="<?php echo base_url()?>addresult" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Add Results</a>
         <a href="<?php echo base_url()?>oplabpendingreport" class="btn text-white mb-3  ml-2"  style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Pending Reports</a>
         <a href="<?php echo base_url()?>oplabfinalreport" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Final Report</a>
         <a href="<?php echo base_url()?>oplabsetting" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Settings</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Ward Billing</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">External </a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Report Dispatcyh</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">LIS</a>

       </div>
      </div>
    





<div class="col-lg-12 mt-5">
                     <div class="row">
                       
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image:linear-gradient(-20deg, #e7505a 0%, #ff825c 100%)">
                                 <div class="d-flex  justify-content-between">
                                 	<h4 class="text-white">Test Request Today</h4><br>
                                 	<div class=""></div>
                                 	<br>
                                      <div class="text-right">                                 
                                       <h2 class="mb-0 text-white" ><span class="counter">3450</span></h2>
                                       
                                    </div>
                                    
                                 </div>
                                  <div class="row mt-3">
	                                 <div class="text-white col-lg-3">
	                                    New :                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-4 float-end">    
	                                    Res. Pending:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Complete:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                                     <div class="row mt-2">
	                                 <div class="text-white col-lg-6">
	                                    Cancelled:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class="text-right text-white col-lg-6 float-end">    
	                                    Returned:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                              </div>
                           </div>
                           
                        </div>
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" 
                              style="height:100%; background-image: linear-gradient(to top, #0773bc 0%, #32c5d2 100%);">
                                 <div class="d-flex  justify-content-between ">
                                 	 <h4 class="text-white">Test Request Till Date</h4>
                                    <div class="text-right mt-7">                                 
                                       <h2 class="mb-0 text-white"><span class="counter">3500</span></h2>
                                      
                                    </div>
                                    
                                 </div>
                                   <div class="row mt-3">
	                                 <div class="text-white col-lg-3">
	                                    New :                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-4 float-end">    
	                                    Res. Pending:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Complete:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                                 <div class="row mt-2">
	                                 <div class="text-white col-lg-6">
	                                    Cancelled:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class="text-right text-white col-lg-6 float-end">    
	                                    Returned:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                              </div>
                           </div>
                        </div>
                        
                     </div>
                  </div>
