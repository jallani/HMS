   <div class="ml-4 mb-3">
        <h3 class="text-dark font-weight-bold ">OP LAB</h3>
      </div>


 <div class="ml-4 ">
  <div class="">
    <a href="<?php echo base_url()?>samplecollection" class="btn text-white  mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Sample Collection </a>
         <a href="<?php echo base_url()?>addresult" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Add Results</a>
         <a href="<?php echo base_url()?>oplabpendingreport" class="btn text-white mb-3  ml-2"  style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Pending Reports</a>
         <a href="<?php echo base_url()?>oplabfinalreport" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Final Report</a>
         <a href="<?php echo base_url()?>oplabsetting" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Settings</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Ward Billing</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">External </a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Report Dispatcyh</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">LIS</a>

       </div>
      </div>
    





<div class="col-lg-12 mt-5">
                     <div class="row">
                        <div class="col-md-4 col-lg-3">
                            <a href="<?php echo base_url() ?>oplabtest">
                           <div class="iq-card iq-card-block iq-card-stretch" >
                              <div class="iq-card-body  rounded" style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white"><i class="fas fa-vial"></i>  &nbsp;&nbsp;LAB TEST</h5><br>
                                    <div class=""></div>
                                    
                                 </div>
                              </div>
                           </div>
                       </a>
                        </div>
                        <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;LAB Test Components</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;Report Templates</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;Default Signatories</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;Venders</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;Lookups</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;LAB Categories</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                          <div class="col-md-4 col-lg-3">
                            <a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " >
                              <div class="iq-card-body  rounded " style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                    <h5 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;Map Government Items</h5><br>
                                    <div class=""></div>
                                    
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                        
                        
                     </div>
                  </div>