    <div class="ml-4 mb-3">
         <h3 class="text-dark font-weight-bold ">Add Result</h3>
      </div>

 <div class="ml-4 ">
  <div class="">
 <a href="<?php echo base_url()?>samplecollection" class="btn text-white  mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Sample Collection </a>
         <a href="<?php echo base_url()?>addresult" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Add Results</a>
         <a href="<?php echo base_url()?>oplabpendingreport" class="btn text-white mb-3  ml-2"  style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Pending Reports</a>
         <a href="<?php echo base_url()?>oplabfinalreport" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Final Report</a>
         <a href="<?php echo base_url()?>oplabsetting" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Settings</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Ward Billing</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">External </a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">Report Dispatcyh</a>
         <a href="<?php echo base_url()?>nursingdischarge" class="btn text-white mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);">LIS</a>

       </div>
      </div>


      <div class="row ml-4">
   <div class="col-lg-12">
      <div class="row">
      <div class="form-group col-lg-1">
                                 <label for="exampleInputdate">From :</label>
                           </div>
                           <div class="col-lg-2">

                                 <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                              </div>
                     

                              <div class="form-group ">
                                 <label for="exampleInputtime">To :</label>
                             </div>
                             <div class="col-lg-2">
                                 <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                              </div>
                              <button class="btn btn-primary">1 D</button>&nbsp;
                               <button class="btn btn-success">OK</button>

                          </div>
                          <div class="row mt-4">
                           <div class="col-lg-12">
                              <div class="row">
                              <div class="col-lg-4">
                           <div class="form-group">
                               
                                 <select class="form-control" id="exampleFormControlSelect1">
                                    <option selected="" disabled="">Select </option>
                                    <option>0</option>
                                    <option>0</option>
                                    <option>0</option>
                                    <option>0</option>
                                    <option>0</option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-lg-4">
                               <div class="form-group">
                               
                                 <select class="form-control" id="exampleFormControlSelect1">
                                    <option selected="" disabled="">Select </option>
                                    <option>Biochemistry</option>
                                    <option>Hematology</option>
                                    <option>Microbiology</option>
                                    <option>Parasitology</option>
                                    <option>Serology</option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-lg-2">
                              <buttom class="btn btn-success">Work list</buttom>
                           </div>
                        </div>
                        </div>
                     </div>

                                                       <div class="row mt-2">
                                                          <div class="col-sm-12">
                                                             <div class="iq-card ">
                                                                <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title">
                              <h4 class="card-title text-white">List Results</h4>
                           </div>
                        </div>
                                                             
                                                                <div class="iq-card-body ">
                                                                   <div id="table" class="table-editable">
                                                                      <span class="table-add float-right mb-3 mr-2 bg-primary">

                                                                     
                                                                      </span>
                                                                      <table class="table table-bordered table-responsive-md table-striped text-center">
                                                                         <thead>
                                                                            <tr>
                                                                              <th>Req. Date</th>
                                                                              <th>Patient Name</th>
                                                                              <th> Age / Sex</th>
                                                                              <th>Phone no.</th>
                                                                              <th>Requesting Depart.</th>
                                                                              <th> Visit Type</th>
                                                                              <th>Run Number type</th>
                                                                              <th>Bar Code</th>
                                                                              <th>Action</th>
                                                                            </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                            <tr>
                                                                              <td contenteditable="true">2022-04-28/01:09 PM</td>
                                                                               <td contenteditable="true">ALi</td>
                                                                               <td contenteditable="true">29 Y/Male</td>
                                                                               <td contenteditable="true">OPD</td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               
                                                                             
                                                                             
                                                                            </tr>
                                                                          
                                                                            
                                                                            
                                                                         </tbody>
                                                                      </table>
                                                                   </div>
                                                                </div>
                                                             </div>
                                                          </div>
                                                       </div>
                                                  
