   <div class="ml-4 mb-3">
        <h3 class="text-dark font-weight-bold ">LAb Test</h3>
      </div>
 <div class="ml-4 ">
  <div class="">
    <a href="<?php echo base_url()?>samplecollection" class="btn text-white  mb-3  ml-2" style=" background-image: linear-gradient(to top, #8080ff 0%, #99bbff 100%);"><i class="fa fa-plus-square"></i>Add New LAb Test </a>
        

       </div>
      </div>
      <div class="iq-search-bar">
                     <form action="#" class="searchbox">
                        <input type="text" class="text search-input" placeholder="Type here to search...">
                        <a class="search-link" href="#"><i class="ri-search-line"></i></a>
                     </form>
                  </div>



       <div class="row mt-2">
                                                          <div class="col-sm-12">
                                                             <div class="iq-card ">
                                                                  <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title">
                              <h4 class="card-title text-white">Lab Test</h4>
                           </div>
                        </div>
                                                             
                                                                <div class="iq-card-body ">
                                                                   <div id="table" class="table-editable">
                                                                      <span class="table-add float-right mb-3 mr-2 bg-primary">

                                                                     
                                                                      </span>
                                                                      <table class="table table-bordered table-responsive-md table-striped text-center">
                                                                         <thead>
                                                                            <tr>
                                                                              <th>Lab Test</th>
                                                                              <th>Patient Name</th>
                                                                              <th> Reporting NAme</th>
                                                                              <th> Categories</th>
                                                                              <th> Is Active</th>
                                                                              <th> Display</th>
                                                                              <th>Sequence</th>
                                                                              <th>Action</th>
                                                                            </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                            <tr>
                                                                                <td contenteditable="true">2022-04-28/01:09 PM</td>
                                                                               <td contenteditable="true">ALi</td>
                                                                               <td contenteditable="true">29 Y/Male</td>
                                                                               <td contenteditable="true">OPD</td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               <td></td>
                                                                               
                                                                             
                                                                             
                                                                             
                                                                             <td>
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Vitals</button></span>
                                                                                <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Summery</button></span>
                                                                                    
                                                                               </td>
                                                                            </tr>
                                                                          
                                                                            
                                                                            
                                                                         </tbody>
                                                                      </table>
                                                                   </div>
                                                                </div>
                                                             </div>
                                                          </div>
                                                       </div>
                                                  
