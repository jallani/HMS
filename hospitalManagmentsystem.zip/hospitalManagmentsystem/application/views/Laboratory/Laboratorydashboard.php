
<div class="col-lg-12 mt-5">
                     <div class="row">
                        <div class="col-md-4 col-lg-3">
                        	<a href="<?php echo base_url() ?>Oplabdashboard">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                 	<h3 class="text-white"><i class="fas fa-vial"></i>  &nbsp;&nbsp;OP LAB</h3><br>
                                    <div class=""></div>
                                    
                                 </div>
                              </div>
                           </div>
                       </a>
                        </div>
                        <div class="col-md-4 col-lg-3">
                        	<a href="#">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image:linear-gradient(-20deg, #e7505a 0%, #ff825c 100%)">
                                 <div class="d-flex  justify-content-between">
                                 	<h3 class="text-white float-right"><i class="fas fa-vial"></i>  &nbsp;&nbsp;ER LAB</h3><br>
                                 	<div class=""></div>
                                 	
                                    
                                 </div>
                                   
                              </div>
                           </div>
                       </a>
                        </div>
                        
                        
                     </div>
                  </div>
