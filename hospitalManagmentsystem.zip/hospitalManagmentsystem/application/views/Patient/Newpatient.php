<!-- Start Form-->
<div class="ml-5 mt-2">
   <h3 >Add Patient</h3>
   </div>


           <div class="container-fluid mt-2">
               <div class="row">
                  <div class="col-sm-12 col-lg-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">Patient Form</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div class="row">
                              <div class="col-md-3">
                                 <ul id="top-tabbar-vertical" class="p-0">
                                    <li class="active" id="personal">
                                       <a href="javascript:void();">
                                       <i class="ri-lock-unlock-line text-primary"></i><span>Patient Information</span>
                                       </a>
                                    </li>
                                    <li id="contact">
                                       <a href="javascript:void();">
                                       <i class="ri-user-fill text-danger"></i><span>Visit Information</span>
                                       </a>
                                    </li>
                                    <li id="official">
                                       <a href="javascript:void();">
                                       <i class="ri-camera-fill text-success"></i><span>Payment</span>
                                       </a>
                                    </li>
                                   
                                 </ul>
                              </div>
                              <div class="col-md-9">
                                 <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          <div class="row">
                                             <div class="col-12">
                                                <h3 class="mb-4">Patient Information:</h3>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="fname">Patient Name: *</label>
                                                   <input type="text" class="form-control" id="fname" name="fname" placeholder="Patient Name" required="required" />
                                                </div>
                                             </div>
                                             
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label>Gender: *</label>
                                                   <div class="form-check">
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio1"> Male</label>
                                                      </div>
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio2"> Female</label>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="dob">Date Of Birth: *</label>
                                                   <input type="date" class="form-control" id="dob" name="dob" />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="lname">Phone No: *</label>
                                                   <input type="text" class="form-control"  placeholder="+92 340 5687887" />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="lname">Address: *</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="lname">Membership: *</label>
                                                   <input type="text" class="form-control"  placeholder="Membership" />
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <button id="submit" type="button" name="next" class="btn btn-primary next action-button float-right" value="Next" >Next</button>
                                    </fieldset>
                                    <fieldset>
                                       <div class="form-card text-left">
                                          <div class="row">
                                             <div class="col-12">
                                                <h3 class="mb-4">Visit Information:</h3>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="email">Department Nmae: *</label>
                                                   <input type="text" class="form-control"  name="dept-name" placeholder="Departmrnt name" />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="ccno">Doctor: *</label>
                                                   <input type="text" class="form-control"  placeholder="Doctoe name" />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="city">Diagnosis: *</label>
                                                   <input type="text" class="form-control" placeholder="Diagnosis." />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                      <label for="exampleInputdate">Visit Date</label>
                                                      <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                   </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Visit Time</label>
                                                   <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <button type="button" name="next" class="btn btn-primary next action-button float-right" value="Next" >Next</button>
                                       <button type="button" name="previous" class="btn btn-dark previous action-button-previous float-right mr-3" value="Previous" >Previous</button>
                                    </fieldset>
                                   
                                    <fieldset>
                                       <div class="form-card text-left">
                                          <div class="row">
                                             <div class="col-12">
                                                <h3 class="mb-4 text-left">Billing Information:</h3>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="panno">Pan No: *</label>
                                                   <input type="text" class="form-control" id="panno" name="panno" placeholder="Pan No." />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="accno">Account No: *</label>
                                                   <input type="text" class="form-control" id="accno" name="accno" placeholder="Account No." />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="holname">Account Holder Name: *</label>
                                                   <input type="text" class="form-control" id="holname" name="accname" placeholder="Account Holder Name." />
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                   <label for="ifsc">IFSC Code: *</label>
                                                   <input type="text" class="form-control" id="ifsc" name="ifsc" placeholder="IFSC Code." />
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <a class="btn btn-primary action-button float-right" href="form-wizard-vertical.html" >Submit</a>
                                       <button type="button" name="previous" class="btn btn-dark previous action-button-previous float-right mr-3" value="Previous" >Previous</button>
                                    </fieldset>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>







             <!-- from End -->
