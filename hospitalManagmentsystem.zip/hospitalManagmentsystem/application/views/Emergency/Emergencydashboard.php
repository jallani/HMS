 <div class="ml-5">
 	<a href="<?php echo base_url()?>Emergencydashboard" class="btn btn-outline-primary mb-3  ml-2" ><i class="fa fa-home"  aria-hidden="true"></i></a>
 	<a href="<?php echo base_url()?>Emg_new_patients" class="btn btn-outline-primary mb-3  ml-2">New Patient</a>
         <a href="<?php echo base_url()?>Emg_Triage_Patient" class="btn btn-outline-primary mb-3  ml-2">Triaged Patient</a>
         <a href="<?php echo base_url()?>Emp_Finalize_patient" class="btn btn-outline-primary mb-3  ml-2">Finalized Patients</a>
         <a href="<?php echo base_url()?>bedinformation" class="btn btn-outline-primary mb-3  ml-2">Bed Information</a>
      </div>



<div class="col-lg-12 mt-5">
                     <div class="row">
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch" style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image: linear-gradient(-20deg, #19a2ff 0%, #0773bc 100%);">
                                 <div class="d-flex  justify-content-between">
                                 	<h6 class="text-white">Total Emergency Patient Registered Today</h6><br>
                                    <div class=""></div>
                                    <div class="text-right"  id="topmarginemg">                                 
                                       <h2 class="mb-0 text-white" ><span class="counter">5600</span></h2>
                                       
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" style="height:100%; background-image:linear-gradient(-20deg, #e7505a 0%, #ff825c 100%)">
                                 <div class="d-flex  justify-content-between">
                                 	<h6 class="text-white">Total Patient Patient Triaged Today</h6><br>
                                 	<div class=""></div>
                                 	<br>
                                      <div class="text-right">                                 
                                       <h2 class="mb-0 text-white" ><span class="counter">3450</span></h2>
                                       
                                    </div>
                                    
                                 </div>
                                  <div class="row">
	                                 <div class="text-white col-lg-3">
	                                    Mild:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Moderate:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Cirtical:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                           <div class="iq-card iq-card-block iq-card-stretch " style="height:80%;">
                              <div class="iq-card-body  rounded" 
                              style="height:100%; background-image: linear-gradient(to top, #0773bc 0%, #32c5d2 100%);">
                                 <div class="d-flex  justify-content-between ">
                                 	 <h6 class="text-white">Patients</h6>
                                    <div class="text-right mt-7">                                 
                                       <h2 class="mb-0 text-white"><span class="counter">3500</span></h2>
                                      
                                    </div>
                                    
                                 </div>
                                  <div class="row">
	                                 <div class="text-white col-lg-3">
	                                    LAMA:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Admitted:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class=" text-white col-lg-3 float-end">    
	                                    Transferred:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                                 <div class="row">
	                                 <div class="text-white col-lg-6">
	                                    Discharge:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
	                                    <div class="text-right text-white col-lg-6 float-end">    
	                                    Death:                             
	                                       <h6 class="mb-0 text-white"> <span class="counter">0</span></h6>
	                                      
	                                    </div>
                                    </div>
                              </div>
                           </div>
                        </div>
                        
                     </div>
                  </div>






