  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <div class="tab-content">
                           <div class="tab-pane fade active show" id="Lama" role="tabpanel">
                              <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Leave Against Medical Advice</h4>
                                    </div>
                                 </div>
                                 <div class="iq-card-body">
                                     <!-- Table start From here -->

                                                    <div class="container-fluid mt-1">
                                                       <div class="row">
                                                          <div class="col-sm-12">
                                                             <div class="iq-card">
                                                                <div class="iq-card-body">
                                                                   <div id="table" class="table-editable">
                                                                      <span class="table-add float-right mb-3 mr-2">
                                                                     
                                                                      </span>
                                                                      <table class="table table-bordered table-responsive-md table-striped text-center">
                                                                         <thead>
                                                                            <tr>
                                                                               <th>Name</th>
                                                                               <th>Age</th>
                                                                               <th>Gender</th>
                                                                               <th>Finalized Date / Time</th>
                                                                               
                                                                               <th>Action</th>
                                                                               
                                                                            </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                            <tr>
                                                                               <td contenteditable="true">ALi</td>
                                                                               <td contenteditable="true">29 Y</td>
                                                                               <td contenteditable="true">Male</td>
                                                                             <td contenteditable="true">2022-04-28/01:09 PM</td>
                                                                             
                                                                             
                                                                             <td>
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                                                               
                                                                                  <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Vitals</button></span>
                                                                                <span class="table-remove"><button type="button"
                                                                                     class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Add Summery</button></span>
                                                                                    
                                                                               </td>
                                                                            </tr>
                                                                          
                                                                            
                                                                            
                                                                         </tbody>
                                                                      </table>
                                                                   </div>
                                                                </div>
                                                             </div>
                                                          </div>
                                                       </div>
                                                    </div>


                                                    <!-- Table End  here -->
                                       
                                      
      
                                </div>
                                </div>
                        </div>
                </div>
        </div>
</div>
