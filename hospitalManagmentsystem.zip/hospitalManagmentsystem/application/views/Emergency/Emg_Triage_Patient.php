
 <div class="ml-5">
   <a href="<?php echo base_url()?>Emergencydashboard" class="btn btn-outline-primary mb-3  ml-2" ><i class="fa fa-home"  aria-hidden="true"></i></a>
   <a href="<?php echo base_url()?>Emg_new_patients" class="btn btn-outline-primary mb-3  ml-2">New Patient</a>
         <a href="<?php echo base_url()?>Emg_Triage_Patient" class="btn btn-outline-primary mb-3  ml-2">Triaged Patient</a>
         <a href="<?php echo base_url()?>Emp_Finalize_patient" class="btn btn-outline-primary mb-3  ml-2">Finalized Patients</a>
         <a href="<?php echo base_url()?>bedinformation" class="btn btn-outline-primary mb-3  ml-2">Bed Information</a>
      </div>


<div class="ml-3 mt-2">
               <h3>Triage Patient</h3>
            </div>


<div class="row ml-2 mt-2">
    <div class="col-lg-6">
                                                <div class="form-group">
                                                   
                                                   <input type="text" class="form-control"  placeholder="Existing Patient" required="required" />
                                                </div>

                                             </div>
                                             <div class="">
                                                <div class="form-group">
                                                   
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">All</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>

                                                </div>
                                             </div>
                                            
                    
                        
                

        
</div>
<!--end  Existing button  -->
    
   









           <!-- Table start From here -->

            <div class="container-fluid mt-1">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">New Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>SN</th>
                                       <th>Triage Status</th>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Address</th>
                                       <th>Visit</th>
                                       <th>Date/Time</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td>1</td>
                                       <td class="text-danger">Death</td>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+96245751255488</td>
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                     <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Assign Doctor</button></span>
                                       
                                            <span class="table-remove">
                                                <a href="#outcome1" class="iq-waves-effect collapsed btn btn-primary mt-1" data-toggle="collapse" aria-expanded="false"><span>Outcome</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                                                <ul id="outcome1" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                                   <li><a href="" class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-outcome">Admin</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-tp"> Transfer</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dc">Discharge </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-lama">LAMA </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-death">Death </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dor"> dortor </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-upload"> Upload Consent </a></li>
                                                </ul>
                                             </span>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>2</td>
                                       <td class="text-success">Mild</td>
                                      <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">30 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                       <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Assign doctor</button></span>
                                       
                                            <span class="table-remove">
                                                <a href="#outcome2" class="iq-waves-effect collapsed btn btn-primary mt-1" data-toggle="collapse" aria-expanded="false"><span>Outcome</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                                                <ul id="outcome2" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                                   <li><a href="" class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-outcome">Admin</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-tp"> Transfer</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dc">Discharge </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-lama">LAMA </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-death">Death </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dor"> dortor </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-upload"> Upload Consent </a></li>
                                                </ul>
                                             </span>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>3</td>
                                       <td class="text-success">Mild</td>
                                       <td contenteditable="true">Hina</td>
                                       <td contenteditable="true">25 Y/Female</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                     <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Assign Doctor</button></span>
                                       
                                            <span class="table-remove">
                                                <a href="#outcome3" class="iq-waves-effect collapsed btn btn-primary mt-1" data-toggle="collapse" aria-expanded="false"><span>Outcome</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                                                <ul id="outcome3" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                                   <li><a href="" class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-outcome">Admin</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-tp"> Transfer</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dc">Discharge </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-lama">LAMA </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-death">Death </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dor"> Doctor </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-upload"> Upload Consent </a></li>
                                                </ul>
                                             </span>
                                       </td>
                                    </tr>
                                    <tr class="hide">
                                       <td>4</td>
                                       <td class="text-warning">Critical</td>
                                      <td contenteditable="true">Saad</td>
                                       <td contenteditable="true">26 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-order">Order</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                            class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Assign Doctor</button></span>
                                       
                                          <span class="table-remove">
                                                <a href="#outcome4" class="iq-waves-effect collapsed btn btn-primary mt-1" data-toggle="collapse" aria-expanded="false"><span>Outcome</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                                                <ul id="outcome4" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                                   <li><a href="" class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-outcome">Admin</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-tp"> Transfer</a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dc">Discharge </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-lama">LAMA </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-death">Death </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-dor"> Doctor </a></li>
                                                   <li><a class="btn btn-primary mt-1 text-white" data-toggle="modal" data-target=".bd-example-modal-upload"> Upload Consent </a></li>
                                                </ul>
                                             </span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->


            <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Upload Image</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-6">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Enter Doctor Name</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>


                           <!-- End Triage Patient -->



                           <!-- Admin Outcome -->


                               <div class="modal fade bd-example-modal-outcome" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Reserve Bed For {Patient Name}</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    

                                    
                                          
                                    <div class="row ml-2 mr-2">
                                    <div class="col-lg-12">
                                             <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         <div class="row">
                                                            <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Requesting Department</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Admitting Doctor</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Ward</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Bed Feature</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Bed</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Admission Date</label>
                                                                        <div class="row">
                                                                        <div class="col-lg-6">
                                                                          <input type="date" class="form-control" id="exampleInputdate" value="2019-12-16">
                                                                          </div>
                                                                          <div class="col-lg-6">
                                                                           <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                                           </div>
                                                                        </div>
                                                                     </div>
                                                               </div>
                                                                <div class="col-lg-6">
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Admission Notes</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                         </div>




                                                            </form>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>
                                                <button type="button" class="btn btn-danger float-right" data-dismiss="modal">Reserve</button>

                                    </div>
                                 </div>
                                    
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>


                           <!-- End  Admin Outcome -->


                            <!-- TP Outcome -->

                              <div class="modal fade bd-example-modal-tp" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Transfer Patient</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-8">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Remarks</label>
                                                                          <input type="textarea" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Transfer Patient</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>



                            <!-- End TP Outcome -->

                                  <!-- Discharge Outcome -->

                              <div class="modal fade bd-example-modal-dc" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Patient Discharge</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-8">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Remarks</label>
                                                                          <input type="textarea" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Discharge</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>



                            <!-- End Discharge Outcome -->

                                  <!-- LAMA Outcome -->

                              <div class="modal fade bd-example-modal-lama" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Leaave Against Medical Advice</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-8">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Remarks</label>
                                                                          <input type="textarea" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Leaave Against Medical Advice</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>



                            <!-- End LAMA Outcome -->

                                  <!-- Death Outcome -->

                              <div class="modal fade bd-example-modal-death" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Patient Death</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-8">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Remarks</label>
                                                                          <input type="textarea" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Death</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>



                            <!-- End Death Outcome -->

      <!-- Dor Outcome -->

                              <div class="modal fade bd-example-modal-dor" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Doctor</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-3">
                                                     <h4>Name :<br> Umer </h4>
                                                  </div>
                                                  <div class="col-lg-3">
                                                     <h4>Age/Sex :<br> 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date/Time: <br>12-03-1992/12:00 AM</h4>
                                                  </div>
                                                 
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-8">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Remarks</label>
                                                                          <input type="textarea" class="form-control"  />
                                                                     </div>
                                                               </div>
                                                               
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>

                                    </div>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Doctor</button>
                                    <div class="modal-footer">
                                      
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>



                            <!-- End DOR Outcome -->


                             <div class="modal fade bd-example-modal-upload" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Upload Image</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                     <h4>Name : Umer </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Age/Sex : 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Date of Birth : 12-03-1992</h4>
                                                  </div>
                                                  <div class="col-lg-6">

                                                     <h4>Address : H#899 st#6 B-block Islammabad Pahase 9 </h4>

                                                  </div>
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-6">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Display Name</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                        
                                                          
                                                            
                                                           
                                                            
                                                                  <div class="custom-file">
                                                                     <label for="exampleFormControlSelect1">Upload Image</label>
                                                                     <input type="file" class="custom-file-input" id="customFile">
                                                                     <label class="custom-file-label" for="customFile">Choose file</label>
                                                                  </div>
                                                               </div>
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>


                           <!-- End Triage Patient -->


                            <!-- Extra large modal -->
                           
                           <div class="modal fade bd-example-modal-order" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">All Orders Of [Patient Name]</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                      <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="iq-card">
                        <div class="iq-card-body p-0">
                           <div class="iq-edit-list">
                              <ul class="iq-edit-profile d-flex nav nav-pills">
                                 <li class="col-md-3 p-0">
                                    <a class="nav-link active" data-toggle="pill" href="#personal-information">
                                   Lab /Imaging Orders
                                    </a>
                                 </li>
                                 <li class="col-md-3 p-0">
                                    <a class="nav-link" data-toggle="pill" href="#chang-pwd">
                                    Phrmacy Order
                                    </a>
                                 </li>
                                 
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <div class="tab-content">
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                              <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Lab /Imaging Orders</h4>
                                    </div>
                                 </div>
                                 <div class="iq-card-body">
                                    <div class="row">
                                                   
                                                  <div class="col-lg-6">
                                                     <h4>Age/Sex :</h4> <h6>27 Y/ Male </h6>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date / Time : </h4><h6>2-03-1992 / 12:00 PM</h6>
                                                  </div>
                                                  
                                                  
                                             </div>
                                    <form>
                                        
                                              <table class="table table-bordered table-responsive-md table-striped text-center mt-2">
                                                <thead>
                                                   <tr class="bg-primary">
                                                      <th>Department</th>
                                                      <th>Requested by Dr.</th>
                                                      <th>Assigned To Dr.</th>
                                                      <th>Item Name</th>
                                                      <th>Qty</th>
                                                      <th>Price</th>
                                                      <th>Date/Time</th>
                                                      <th>Action</th>
                                                      
                                                   </tr>
                                                </thead>
                                                <tbody>
                                                   <tr>
                                                      <td>1</td>
                                                      <td class="text-danger">qw</td>
                                                      <td contenteditable="true">qwqw</td>
                                                      <td contenteditable="true">qwq/td>
                                                      <td contenteditable="true">qwq</td>
                                                      <td contenteditable="true">678</td>
                                                    <td contenteditable="true">qwe</td>
                                                    <td contenteditable="true">qwe</td>
                                                    
                                                   </tr>
                                                 </tbody>
                                             </table>
                                     
                                       <div class=" row align-items-center">
                                         
                                          <div class="col-lg-7">
                                             <button type="button" class="btn btn-primary float-right"> Request</button>
                                          </div>
                                       </div>
                                     
                                         
                                         <div class="row mt-3">
                                          <div class="col-lg-6">
                                             <div class="iq-search-bar">
                                                   <form action="#" class="searchbox">
                                                      <input type="text" class="text search-input" placeholder="Type here to search...">
                                                      
                                                   </form>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                             <button type="button" class="btn btn-primary float-right"> Print</button>
                                          </div>
                                          </div>

                                           <table class="table table-bordered table-responsive-md table-striped text-center mt-4">
                                                <thead>
                                                   <tr class="bg-primary">
                                                      <th>Department</th>
                                                      <th>Requested by Dr.</th>
                                                      <th>Assigned To Dr.</th>
                                                      <th>Item Name</th>
                                                      <th>Qty</th>
                                                      <th>Added By</th>
                                                      <th>Status</th>
                                                      <th>Action</th>
                                                      
                                                   </tr>
                                                </thead>
                                                 <tbody>
                                                   <tr>
                                                      <td>1</td>
                                                      <td class="text-danger">qw</td>
                                                      <td contenteditable="true">qwqw</td>
                                                      <td contenteditable="true">qwq</td>
                                                      <td contenteditable="true">qwq</td>
                                                      <td contenteditable="true">678</td>
                                                    <td contenteditable="true">qwe</td>
                                                    <td contenteditable="true">qwe</td>
                                                   </tr>
                                                 </tbody>
                                             </table>
                                     
                                       
                                    </form>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="chang-pwd" role="tabpanel">
                              <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Phrmacy Order</h4>
                                    </div>
                                 </div>
                                 <div class=" row align-items-center">
                                         
                                          <div class="col-lg-7 mt-4">
                                             <button type="button" class="btn btn-primary "> New Mediciens</button>
                                          </div>
                                       </div>
                                 <div class="iq-card-body mt-5">
                                    <div class="row">
                                                   
                                                  <div class="col-lg-6">
                                                     <h4>Age/Sex :</h4> <h6>27 Y/ Male </h6>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Visit Date / Time : </h4><h6>2-03-1992 / 12:00 PM</h6>
                                                  </div>
                                                  
                                                  
                                             </div>
                                             <div class="col-lg-9 bg-primary text-white mt-3"><h4 class="text-white">Drug / Medicine Name                 QTY</h4></div>
                                    <form>
                                       <div class="form-group mt-5">
                                          <div class="row">
                                             <div class="col-lg-6">
                                          <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select Medicien</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>
                                                         </div>
                                                         <div class="col-lg-2">
                                                            <div class="form-group">
                                                                        
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                         </div>
                                                          <div class="row">
                                                                <div class="col-lg-6">
                                                                  <button class="btn btn-primary"> +</button>        
                                                               </div>
                                                                <div class="col-lg-6">
                                                                   <button class="btn btn-danger"> x</button>
                                                               </div>
                                                            </div>
                                                      </div>
                                       </div>
                                         
                                       <button type="submit" class="btn btn-primary mr-2">Request</button>
                                   
                                    </form>
                                 </div>
                              </div>
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           
                                    </div>
                                 </div>
                              </div>
                           </div>
                           













                           <!--Start Add New Vital -->

                           <div class="modal fade bd-example-modal-advisit" tabindex="-1" role="dialog"  aria-hidden="true">
                              <div class="modal-dialog modal-lg">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">Add New Vitals</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                         <form>
                                       <div class="form-group mt-1">
                                          <div class="row">
                                             <div class="col-lg-6">
                                          <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Visiter List</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>
                                                         </div>
                                                         
                                       </div>
                                         
                                     
                                   
                                    </form>


                                     <div class="row mt-2">

                                         <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Add On </label>
                                                   <div class="row">
                                                        <div class="col-lg-6">
                                                            <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                         </div>
                                                            <div class="col-lg-6">
                                                            <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>

                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Height</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">CM</option>
                                                            <option>Meter</option>
                                                            <option>Foot 'inch'</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Weight</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Kg</option>
                                                            <option>Ibs</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>BMI</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Temperature</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">F</option>
                                                            <option>C</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Pulse</label>
                                                            <input type="text" class="form-control" > 
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Blood Pressure</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Respiratory Rate</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>SpO2</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>


                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>O2 Delivery Plan</label>
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Room Air</option>
                                                            <option>Nasal cannula</option>
                                                            <option>Face MAsk</option>
                                                            <option>BiPAP </option>
                                                            <option>Mechanical Ventilator</option>
                                                         </select>
                                                         
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Pain Scale (/10)</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">1</option>
                                                            <option>2</option>
                                                             <option>3</option>
                                                              <option>4</option>
                                                               <option>5</option>
                                                                <option>6</option>
                                                                 <option>7</option>
                                                                  <option>8</option>
                                                                   <option>9</option>
                                                                    <option>10</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>

                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Nadi</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Mala</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Mutra</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Jiuha</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>shabda</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Sparsha</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Drik</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Akriti</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Heart Sound</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>PA-Tenderness</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Organomegaly</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>CNs-Consiousness</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Power</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Reflexes</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Tone</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Other</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>





                                        </div>
                                     </div>
                                       
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                       <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>
                                 </div>
                              </div>
                           </div>


                           <!--End Add New Vital -->