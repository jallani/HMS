 <div class="ml-5">
   <a href="<?php echo base_url()?>Emergencydashboard" class="btn btn-outline-primary mb-3  ml-2" ><i class="fa fa-home"  aria-hidden="true"></i></a>
   <a href="<?php echo base_url()?>Emg_new_patients" class="btn btn-outline-primary mb-3  ml-2">New Patient</a>
         <a href="<?php echo base_url()?>Emg_Triage_Patient" class="btn btn-outline-primary mb-3  ml-2">Triaged Patient</a>
         <a href="<?php echo base_url()?>Emp_Finalize_patient" class="btn btn-outline-primary mb-3  ml-2">Finalized Patients</a>
         <a href="<?php echo base_url()?>bedinformation" class="btn btn-outline-primary mb-3  ml-2">Bed Information</a>
      </div>




<div class="row ml-2">
    <div class="col-lg-6">
                                                <div class="form-group">
                                                   
                                                   <input type="text" class="form-control"  placeholder="Existing Patient" required="required" />
                                                </div>

                                             </div>
                                             <div class="">
                                                <div class="form-group">
                                                   
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">All</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>

                                                </div>
                                             </div>
                                             <div class="col-lg-4">
                                               <button type="button" class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">New Register</button>
                                             </div>
        
                    
                        
                

        
</div>
<!--end  Existing button  -->
    
   <!-- Search button  -->
       <div class="iq-search-bar ml-2 mt-2">
                     <form action="#" class="searchbox">
                        <input type="text" class="text search-input" placeholder="Search">
                        <a class="search-link" href="#"><i class="ri-search-line"></i></a>
                     </form>
                

        
           </div>
           <!-- End Search button  -->









           <!-- Table start From here -->

            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">New Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Address</th>
                                       <th>Visit</th>
                                       <th>Date/Time</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                            class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lge">Triage</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                            class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xle">Upload Consent</button></span>
                                       </td>
                                    </tr>
                                    <tr>
                                      <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">30 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                       <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lge">Triage</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xle">Upload Consent</button></span>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td contenteditable="true">Hina</td>
                                       <td contenteditable="true">25 Y/Female</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lge">Triage</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                            class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xle">Upload Consent</button></span>
                                       </td>
                                    </tr>
                                    <tr class="hide">
                                      <td contenteditable="true">Saad</td>
                                       <td contenteditable="true">26 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     <td contenteditable="true">2022-04-28/01:09 PM</td>
                                     
                                     
                                      <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xl">Edit</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lge">Triage</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-advisit">Add Visits</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                            class="btn btn-primary btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-xle">Upload Consent</button></span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->

<!-- New Register -->

             <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                       <h5 class="modal-title text-white">Emergency Patient Register</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">First Name</label>
                                                           <input type="text" class="form-control"  />
                                                      </div>
                                             </div>
                                           
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Last Name</label>
                                                           <input type="text" class="form-control"  />
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Gender</label>
                                                         <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select Gender</option>
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                            <option>Other</option>
                                                         </select>

                                                           
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Age</label>
                                                           <input type="number" class="form-control" placeholder="Year" />

                                                      </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Date Of Birth</label>
                                                  
                                                   <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                        
                                                            
                                                   </div>
                                                </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">District/State</label>
                                                           <input type="text" class="form-control" placeholder="District/State" />
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Address</label>
                                                           <input type="text" class="form-control" placeholder="Address" />
                                                      </div>
                                             </div>


                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">District/State</label>
                                                           <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select</option>
                                                            <option>General</option>
                                                            <option>Dog Bite</option>
                                                            <option>Snake Bite</option>
                                                            <option>Animal Bite</option>
                                                            <option>Emergency Labou</option>
                                                            <option>Midieo-Legal</option>
                                                         </select>

                                                      </div>
                                             </div>
                                            
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Contact No.</label>
                                                   <input type="number" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Referred By</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Case</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Condition Durinng arrival</label>
                                                   <input type="text" class="form-control">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Mode of Arrival</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Care of Person</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Care of Person Number</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">OT Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Remarks :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                      </div>
                                       </div>

                                      
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary">Add Unknown ER-Patient</button>
                                      
                                       <button type="button" class="btn btn-primary">Register</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>

                           <!--End New Register -->


                           <!-- New update -->

             <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                       <h5 class="modal-title text-white">Emergency Patient Register</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">First Name</label>
                                                           <input type="text" class="form-control"  />
                                                      </div>
                                             </div>
                                           
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Last Name</label>
                                                           <input type="text" class="form-control"  />
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Gender</label>
                                                         <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select Gender</option>
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                            <option>Other</option>
                                                         </select>

                                                           
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Age</label>
                                                           <input type="number" class="form-control" placeholder="Year" />

                                                      </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Date Of Birth</label>
                                                  
                                                   <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                        
                                                            
                                                   </div>
                                                </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">District/State</label>
                                                           <input type="text" class="form-control" placeholder="District/State" />
                                                      </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">Address</label>
                                                           <input type="text" class="form-control" placeholder="Address" />
                                                      </div>
                                             </div>


                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                         <label for="exampleFormControlSelect1">District/State</label>
                                                           <select class="form-control" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Select</option>
                                                            <option>General</option>
                                                            <option>Dog Bite</option>
                                                            <option>Snake Bite</option>
                                                            <option>Animal Bite</option>
                                                            <option>Emergency Labou</option>
                                                            <option>Midieo-Legal</option>
                                                         </select>

                                                      </div>
                                             </div>
                                            
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Contact No.</label>
                                                   <input type="number" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Referred By</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Case</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Condition Durinng arrival</label>
                                                   <input type="text" class="form-control">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Mode of Arrival</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Care of Person</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Care of Person Number</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">OT Assistant Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Remarks :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                      </div>
                                       </div>

                                      
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary">Update</button>
                                      
                                    
                                    </div>
                                 </div>
                              </div>
                           </div>

                           <!--End New UPDAte -->



                           <!--  Triage Patient -->

                           <!-- New Register -->

             <div class="modal fade bd-example-modal-lge" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Triage Patient</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">







            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Visit Date/Time</th>
                                       <th>Case.</th>
                                       <th>Set Triage Code</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">2022-04-28/01:09 PM</td>
                                       <td contenteditable="true"></td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-dark rounded-pill mb-3" id="death">Death</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-danger rounded-pill mb-3">Critical</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-warning rounded-pill mb-3">Moderate</button></span>
                                       
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-success rounded-pill mb-3">Mild</button></span>
                                       </td>
                                    </tr>
                                   
                                 </tbody>
                              </table>
                          
                     </div>
                  </div>
               </div>
            </div>















                                     
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>


                           <!-- End Triage Patient -->




 <div class="modal fade bd-example-modal-xle" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                    <h5 class="modal-title text-white">Upload Image</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">

                                    <div class="container-fluid mt-5">
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="iq-card">
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                     <h4>Name : Umer </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Age/Sex : 27 Y/ Male </h4>
                                                  </div>
                                                  <div class="col-lg-6">
                                                     <h4>Date of Birth : 12-03-1992</h4>
                                                  </div>
                                                  <div class="col-lg-6">

                                                     <h4>Address : H#899 st#6 B-block Islammabad Pahase 9 </h4>

                                                  </div>
                                                  
                                             </div>
                                          </div>
                                       </div>
                                    
                                    <div class="col-lg-6">
                            <form id="form-wizard3" >
                                                   <!-- fieldsets -->
                                                  
                                                         
                                                               <div class="form-group">
                                                                        <label for="exampleFormControlSelect1">Display Name</label>
                                                                          <input type="text" class="form-control"  />
                                                                     </div>
                                                        
                                                          
                                                            
                                                           
                                                            
                                                                  <div class="custom-file">
                                                                     <label for="exampleFormControlSelect1">Upload Image</label>
                                                                     <input type="file" class="custom-file-input" id="customFile">
                                                                     <label class="custom-file-label" for="customFile">Choose file</label>
                                                                  </div>
                                                               </div>
                                                           
                                                           
                                                  
                                                  
                                                  
                                                </form>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        </div>


                           <!-- End Triage Patient -->













                           <!--  Alerts Patient -->

                           <div class="alert alert-success text-center" id="alert-death" role="alert"   style="display: none;" >
                             Success
                              Patient is successfully triaged [death]
                           </div>

                            <div class="alert alert-success text-center" role="alert" hidden>
                             Success
                              Patient is successfully triaged [Critical]
                           </div>
                            <div class="alert alert-success text-center" role="alert" hidden>
                             Success
                              Patient is successfully triaged [Moderate]
                           </div>
                            <div class="alert alert-success text-center" role="alert" hidden>
                             Success
                              Patient is successfully triaged [Mild]
                           </div>


                           <script type="text/javascript">
                             const triggers = [
                                                  'death',
                                                  'secondary',
                                                  'success',
                                                  'danger',
                                                  'warning',
                                                  'info',
                                                  'light',
                                                  'dark',
                                                ];
                                                const basicInstances = [
                                                  'alert-death',
                                                  'alert-secondary',
                                                  'alert-success',
                                                  'alert-danger',
                                                  'alert-warning',
                                                  'alert-info',
                                                  'alert-light',
                                                  'alert-dark',
                                                ];

                                                triggers.forEach((trigger, index) => {
                                                  let basicInstance = mdb.Alert.getInstance(document.getElementById(basicInstances[index]));
                                                  document.getElementById(trigger).addEventListener('click', () => {
                                                    basicInstance.show();
                                                  });
                                                });
                           </script>


                           <!-- End Alerts  -->

                                       


                           <!--Start Add New Vital -->

                           <div class="modal fade bd-example-modal-advisit" tabindex="-1" role="dialog"  aria-hidden="true">
                              <div class="modal-dialog modal-lg">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">Add New Vitals</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                         <form>
                                       <div class="form-group mt-1">
                                          <div class="row">
                                             <div class="col-lg-6">
                                          <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Visiter List</option>
                                                            <option>Umer</option>
                                                            <option>Saad</option>
                                                            <option>Hussain</option>
                                                            <option>Ali</option>
                                                            <option>Hina</option>
                                                         </select>
                                                         </div>
                                                         
                                       </div>
                                         
                                     
                                   
                                    </form>


                                     <div class="row mt-2">

                                         <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Add On </label>
                                                   <div class="row">
                                                        <div class="col-lg-6">
                                                            <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                         </div>
                                                            <div class="col-lg-6">
                                                            <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>

                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Height</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">CM</option>
                                                            <option>Meter</option>
                                                            <option>Foot 'inch'</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Weight</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Kg</option>
                                                            <option>Ibs</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>BMI</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Temperature</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">F</option>
                                                            <option>C</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Pulse</label>
                                                            <input type="text" class="form-control" > 
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Blood Pressure</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Respiratory Rate</label>
                                                            <input type="text" class="form-control" >
                                                         
                                                            
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>SpO2</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>


                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>O2 Delivery Plan</label>
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">Room Air</option>
                                                            <option>Nasal cannula</option>
                                                            <option>Face MAsk</option>
                                                            <option>BiPAP </option>
                                                            <option>Mechanical Ventilator</option>
                                                         </select>
                                                         
                                                </div>
                                             </div>
                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Pain Scale (/10)</label>
                                                   <div class="row">
                                                        <div class="col-lg-4">
                                                            <input type="text" class="form-control" >
                                                         </div>
                                                            <div class="col-lg-4">
                                                            <select class="form-control align-items-center" id="exampleFormControlSelect1">
                                                            <option selected="" disabled="">1</option>
                                                            <option>2</option>
                                                             <option>3</option>
                                                              <option>4</option>
                                                               <option>5</option>
                                                                <option>6</option>
                                                                 <option>7</option>
                                                                  <option>8</option>
                                                                   <option>9</option>
                                                                    <option>10</option>
                                                         </select>
                                                         </div>
                                                   </div>
                                                </div>
                                             </div>

                                              <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Nadi</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Mala</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Mutra</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Jiuha</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>shabda</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Sparsha</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Drik</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Akriti</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Heart Sound</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>PA-Tenderness</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Organomegaly</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>CNs-Consiousness</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Power</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Reflexes</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Tone</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>
                                                 <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Other</label>
                                                            <input type="text" class="form-control" >
                                                   </div>
                                                </div>





                                        </div>
                                     </div>
                                       
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                       <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>
                                 </div>
                              </div>
                           </div>


                           <!--End Add New Vital -->