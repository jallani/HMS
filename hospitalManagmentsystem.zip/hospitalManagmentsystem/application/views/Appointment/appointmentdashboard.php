 <div><a href="<?php echo base_url()?>appointmentbookinglist" class=" ml-4 text-primary">Appointment Booking List</a>
         <a href="<?php echo base_url()?>phonebookappointment" class=" ml-4 text-primary">Phone Book Appointment</a><a href="<?php echo base_url()?>listvisits" class=" ml-4 text-primary">List Visits</a>
      </div>

            <div class="ml-3 mt-2">
               <h3>Patient List | &nbsp;<a href="<?php echo base_url()?>Newpatient" class="btn btn-primary">New Patient</a>
            </div>




            <!-- Table start From here -->

            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title">
                              <h4 class="card-title text-white">Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Address</th>
                                       <th>Phone no.</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn iq-bg-primary btn-rounded btn-sm my-0">Check in</button></span>
                                       </td>
                                    </tr>
                                    <tr>
                                      <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">30 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn  btn-primary btn-sm my-0">check in</button></span>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td contenteditable="true">Hina</td>
                                       <td contenteditable="true">25 Y/Female</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0">check in</button></span>
                                       </td>
                                    </tr>
                                    <tr class="hide">
                                      <td contenteditable="true">Saad</td>
                                       <td contenteditable="true">26 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button"
                                             class="btn btn-primary btn-sm my-0">check in</button></span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->

