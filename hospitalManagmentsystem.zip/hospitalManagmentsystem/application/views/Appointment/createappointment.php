   <!-- TOP Nav Bar END -->
         <div><a href="<?php echo base_url()?>appointmentbookinglist.html" class=" ml-4 text-primary">Appointment Booking List</a>
         <a href="<?php echo base_url()?>phonebookappointment"  class=" ml-4 text-primary">Phone Book Appointment</a><a href="<?php echo base_url()?>" class=" ml-4 text-primary">List Visits</a>
      </div>

           <div class="col-md-9">
                                 <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          <div class="row">
                                             <div class="col-12">
                                                <h3 class="mb-4">Patient Information:</h3>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="fname">Patient Name: *</label>
                                                   <input type="text" class="form-control" id="fname" name="fname" placeholder="Patient Name" required="required" />
                                                </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Gender: *</label>
                                                   <div class="form-check">
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio1"> Male</label>
                                                      </div>
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio2"> Female</label>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="dob">Age: *</label>
                                                   <input type="text" class="form-control"  />
                                                   <label for="dob">Year</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Reason: *</label>
                                                   <input type="text" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Contact Number: *</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Appointment Date :</label>
                                                   <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Time Input</label>
                                                   <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Department Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Doctor :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <button id="submit" type="button" name="next" class="btn btn-primary next action-button float-right mb-4" value="Next" >Add Appointment</button>
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                              </div>

                                 



