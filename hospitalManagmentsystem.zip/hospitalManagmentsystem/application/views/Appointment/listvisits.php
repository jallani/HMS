  <div><a href="<?php echo base_url()?>appointmentbookinglist" class=" ml-4 text-primary">Appointment Booking List</a>
         <a href="<?php echo base_url()?>phonebookappointment"  class=" ml-4 text-primary">Phone Book Appointment</a><a href="" class=" ml-4 text-primary">List Visits</a>
      </div>

            <div class="ml-3 mt-2">
               <h3>Phone Booking Appointment</h3>
            </div>

                                 



                                                  <!-- Table start From here -->

            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title">
                              <h4 class="card-title text-white"> List Visits</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       
                                       <th>Date</th>
                                       <th>Time</th>
                                       <th>Name</th>
                                       <th>Phone No.</th>
                                       <th>Age</th>
                                       <th>Department </th>
                                       <th>Doctor</th>
                                       <th>VisitType</th>
                                       <th>App. ID</th>
                                       <th>Days-Passed</th>
                                       <th>Queue No.</th>
                                       <th>Action</th>
                                       
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">2022-10-29</td>
                                       <td contenteditable="true">02:46 AM</td>
                                       <td contenteditable="true">Jenny Victoria Brown</td>
                                       <td contenteditable="true">+98245751255488</td>
                                       <td>33 Y/F</td>
                                       <td>EMERGENCY/CASUALTY</td>
                                       <td>Dr ARAFAT MALVIN</td>
                                       <td>emergency</td>
                                       <td>New</td>
                                       <td>4</td>
                                       <td>1</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Follow up</a>
                                          <a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Sticker</a></span>
                                       </td>
                                    </tr>
                                      <tr>
                                      <td contenteditable="true">2022-10-29</td>
                                       <td contenteditable="true">02:46 AM</td>
                                       <td contenteditable="true">Jenny Victoria Brown</td>
                                       <td contenteditable="true">+98245751255488</td>
                                       <td>33 Y/F</td>
                                       <td>EMERGENCY/CASUALTY</td>
                                       <td>Dr ARAFAT MALVIN</td>
                                       <td>outpatient</td>
                                       <td>New</td>
                                       <td>4</td>
                                       <td>1</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Follow up</a>
                                          <a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Sticker</a></span>
                                       </td>
                                    </tr>
                                      <tr>
                                      <td contenteditable="true">2022-10-29</td>
                                       <td contenteditable="true">02:46 AM</td>
                                       <td contenteditable="true">Jenny Victoria Brown</td>
                                       <td contenteditable="true">+98245751255488</td>
                                       <td>33 Y/F</td>
                                       <td>EMERGENCY/CASUALTY</td>
                                       <td>Dr ARAFAT MALVIN</td>
                                       <td>emergency</td>
                                       <td>New</td>
                                       <td>4</td>
                                       <td>1</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Follow up</a>
                                          <a type="button" href="<?php echo base_url()?>createappointment" 
                                             class="btn btn-primary rounded-pill mb-3 text-white">Sticker</a></span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->


