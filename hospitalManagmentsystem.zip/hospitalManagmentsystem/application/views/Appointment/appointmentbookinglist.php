   <div><a href="" class=" ml-4 text-primary">Appointment Booking List</a>
         <a href="<?php echo base_url()?>phonebookappointment" class=" ml-4 text-primary">Phone Book Appointment</a><a href="<?php echo base_url()?>listvisits" class=" ml-4 text-primary">List Visits</a>
      </div>

            <div class="ml-3 mt-2">
               <h3>Appointment Booking List</h3>
            </div>

                                          <div class="row ml-4 mt-3">
                                             <div class="col-lg-3">
                                                <div class="form-group">
                                                   <label for="fname">Doctor: </label>
                                                   <input type="text" class="form-control"  name="doctor" placeholder="Doctor" />
                                                </div>
                                             </div>
                                              <div class="col-lg-3">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Date Input</label>
                                                   <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                </div>
                                             </div>
                                              <div class="col-lg-3">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Time Input</label>
                                                   <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                </div>
                                             </div>
                                             <div class="col-lg-3 mt-1">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Search Detail</label><br>
                                                   <button class="btn btn-primary ">Show Patient</button>
                                                </div>
                                             </div>
                                          </div>
                              <div class="ml-3 mt-2">
                                                  <h4 class="text-primary"><i class="fa fa-calendar text-primary" aria-hidden="true"></i>&nbsp;Upcoming Appointment</h4>
                                                </div>



                                                  <!-- Table start From here -->

            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title ">
                              <h4 class="card-title text-white">Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>Status</th>
                                       <th>Date</th>
                                       <th>Time</th>
                                       <th>App. ID</th>
                                       <th>Patient Name</th>
                                       <th>Phone No</th>
                                       <th>Doctor</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true" class="text-primary">Initiated</td>
                                       <td contenteditable="true">2022-04-28</td>
                                       <td contenteditable="true">01:09 PM</td>
                                       <td contenteditable="true">2</td>
                                       <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">96545567744</td>
                                       <td contenteditable="true">Dr. KAEDON B RUSLAN</td>
                                       <td contenteditable="true"><button class="btn btn-primary rounded-pill mb-3">Check in</button>
                                       <button class="btn btn-primary rounded-pill mb-3">Cancel</button>
                                    <button class="btn btn-primary rounded-pill mb-3">Edit</button></td>
                                     
                                 
                                    </tr>
                                    <tr>
                                      <td contenteditable="true" class="text-success">CheckedIn</td>
                                       <td contenteditable="true">2021-12-28</td>
                                       <td contenteditable="true">01:09 PM</td>
                                       <td contenteditable="true">1</td>
                                       <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">96545567744</td>
                                       <td contenteditable="true">Dr. KAEDON B RUSLAN</td>
                                       <td contenteditable="true"><button class="btn btn-primary rounded-pill mb-3">Detail</button>
                                    </tr>
                                   
                                    <tr class="hide">
                                     <td contenteditable="true" class="text-primary">Initiated</td>
                                       <td contenteditable="true">2022-06-28</td>
                                       <td contenteditable="true">01:09 PM</td>
                                       <td contenteditable="true">2</td>
                                       <td contenteditable="true">Umer</td>
                                       <td contenteditable="true">96545567744</td>
                                       <td contenteditable="true">Dr. KAEDON B RUSLAN</td>
                                       <td contenteditable="true"><button class="btn btn-primary rounded-pill mb-3">Check in</button>
                                       <button class="btn btn-primary rounded-pill mb-3">Cancel</button>
                                    <button class="btn btn-primary rounded-pill mb-3">Edit</button></td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


            <!-- Table End  here -->






