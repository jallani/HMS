   <div><a href="<?php echo base_url()?>appointmentbookinglist" class=" ml-4 text-primary">Appointment Booking List</a>
         <a href=""  class=" ml-4 text-primary">Phone Book Appointment</a><a href="<?php echo base_url()?>listvisits" class=" ml-4 text-primary">List Visits</a>
      </div>

            <div class="ml-3 mt-2">
               <h3>Phone Booking Appointment</h3>
            </div>

                                 



                                                  <!-- Table start From here -->

            <div class="container-fluid mt-5">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between bg-primary">
                           <div class="iq-header-title">
                              <h4 class="card-title text-white">Patient List</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <div id="table" class="table-editable">
                              <span class="table-add float-right mb-3 mr-2">
                             
                              </span>
                              <table class="table table-bordered table-responsive-md table-striped text-center">
                                 <thead>
                                    <tr>
                                       <th>Patient Name</th>
                                       <th>Age/Sex</th>
                                       <th>Address</th>
                                       <th>Phone no.</th>
                                       <th>Action</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button" 
                                             class="btn btn-primary btn-rounded btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Create Appointment</button></span>
                                       </td>
                                    </tr>
                                      <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button" 
                                             class="btn btn-primary btn-rounded btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Create Appointment</button></span>
                                       </td>
                                    </tr>
                                      <tr>
                                       <td contenteditable="true">ALi</td>
                                       <td contenteditable="true">29 Y/Male</td>
                                       <td contenteditable="true">H#12 St#4 Islamabad b block</td>
                                       <td contenteditable="true">+98245751255488</td>
                                     
                                     
                                       <td>
                                          <span class="table-remove"><button type="button" 
                                             class="btn btn-primary btn-rounded btn-sm my-0" data-toggle="modal" data-target=".bd-example-modal-lg">Create Appointment</button></span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>


















<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"   aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                       <h5 class="modal-title text-white">Phone Booking Appointment | New Patient</h5>
                                       <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="form-wizard3" class="text-center">
                                    <!-- fieldsets -->
                                    <fieldset>
                                       <div class="form-card text-left">
                                          <div class="row">
                                             <div class="col-12">
                                                <h3 class="mb-4">Patient Information:</h3>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="fname">Patient Name: *</label>
                                                   <input type="text" class="form-control" id="fname" name="fname" placeholder="Patient Name" required="required" />
                                                </div>
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label>Gender: *</label>
                                                   <div class="form-check">
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio1"> Male</label>
                                                      </div>
                                                      <div class="custom-control custom-radio custom-control-inline">
                                                         <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                         <label class="custom-control-label" for="customRadio2"> Female</label>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="dob">Age: *</label>
                                                   <input type="text" class="form-control"  />
                                                   <label for="dob">Year</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Reason: *</label>
                                                   <input type="text" class="form-control"   />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="lname">Contact Number: *</label>
                                                   <input type="text" class="form-control"  placeholder="Address" />
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Appointment Date :</label>
                                                   <input type="date" class="form-control" id="exampleInputdate" value="2019-12-18">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputtime">Time Input</label>
                                                   <input type="time" class="form-control" id="exampleInputtime" value="13:45">
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Department Name :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                             <div class="col-lg-6">
                                                <div class="form-group">
                                                   <label for="exampleInputdate">Doctor :</label>
                                                   <input type="text" class="form-control" >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       
                                    </fieldset>
                                   
                                   
                                   
                                 </form>
                                    </div>
                                    <div class="modal-footer">
                                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                       <button type="button" class="btn btn-primary">Add Appointment</button>
                                    </div>
                                 </div>
                              </div>
                           </div>




            <!-- Table End  here -->

