<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class doctormodel extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function adddoctors($doctordata)
	{
		

		$in = $this->db->insert("doctors",$doctordata);
		if($in)
		{
			return true;
		}
		else
		{
			return FALSE;
		}
		
	}
	public function superadminlogin($check_email,$check_password)
	{
		$in = $this->db->select('*');
		$in = $this->db->from('super_admin');
		$in = $this->db->where('superadminemail',$check_email);
		$in = $this->db->where('superadminpassword',$check_password);
		$response = $this->db->get()->row();
		if ($response)
		{
			return $response;
		}
		else
		{
			return FALSE;
		}
	}

	public function alldoctors()
	{
		$in = $this->db->select('*');
		$in = $this->db->from("doctors");
		$alldoctor = $this->db->get()->num_rows();
		return $alldoctor;
	}

}