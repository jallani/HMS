<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class add_superadmincontroller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 * 	
	 */
	public function __construct()
	{
	        parent::__construct();
    	    $this->load->library(array('form_validation','session'));
        	$this->load->helper(array('url','html','form'));
        	$this->load->database();
        	$this->load->model('adminmodel');
        	
        	
    	}
   	
	public function add_superadmincontroller()
	{
		$this->load->model('adminmodel');
		$super_admin_name = $_POST['supername'];
		$super_admin_email = $_POST['superemail'];
		$super_admin_phoneno = $_POST['phoneno'];
		$super_admin_password = $_POST['password'];
		$super_admin_date = $_POST['date'];
		$super_admin_time = $_POST['time'];
		$super_admin_createdby = $_POST['createdby'];


		$superdate ['superadminname'] = $super_admin_name;
		$superdate ['superadminemail'] = $super_admin_email;
		$superdate ['superadminphoneno'] = $super_admin_phoneno;
		$superdate ['superadminpassword'] = $super_admin_password;
		$superdate ['date'] = $super_admin_date;

		$superdate ['time'] = $super_admin_time;
		$superdate ['createdby'] = $super_admin_createdby;

		$response = $this->adminmodel->addsuperadmin($superdate);
		if(!empty($response))
		{
			redirect('home');
		}
		else
		{
			redirect('error404');
		}
		
	}
	
	public function Login()
	{
		$this->load->model('adminmodel');
		$check_email = $_POST['email'];
		$check_password = $_POST['password'];
		$response =$this->adminmodel->superadminlogin($check_email,$check_password);
		if(!empty($response))
		{
			$this->session->set_userdata('superadminid', $response->superadminid);
			$this->session->set_userdata('superadminname', $response->superadminname);
			$this->session->set_userdata('superadminemail', $response->superadminemail);
			$this->session->set_userdata('superadminphoneno', $response->superadminphoneno);
			redirect('home');

		}
		else
		{
			$this->session->set_flashdata('error', 'Email or Password is not correct');
			redirect($_SERVER['HTTP_REFERER']);
		}


	}

	public function logout()
	{
		$this->session->unset_userdata('superadminid');
		$this->session->sess_destroy();
		redirect('/');
	}
}
