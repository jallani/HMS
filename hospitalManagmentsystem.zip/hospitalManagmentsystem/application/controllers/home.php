<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {



	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('login');
	}

	
	public function home()
	{


		// YR IS KA SOLUTION YEH HAI K LOGIN KA NEW CONSTRUCTOR BANAO AUR US M SY LOGIN KA PAGE HI LOAD HO USER JB LOGIN PRESS KARY TOU B WOHI CONTROLLER USE KARY AUR LOGOUT PY B HAN JB LOGIN 
		
		$this->load->model('doctormodel');
		$this->load->model('nursesmodel');
		$this->load->model('patientmodel');
		$this->load->view('header');


		// Show All Doctors
		$alldoctors = $this->doctormodel->alldoctors();
		$allnurses = $this->nursesmodel->allnurses();
		$allpatients = $this->patientmodel->allpatients();
		// print_r($alldoctors);
		// exit();

		$this->load->view('home',["alldoctors"=>$alldoctors,"allnurses"=>$allnurses,"allpatients"=>$allpatients]);
		$this->load->view('footer');
		
	}
	public function appointmentbookinglist()
	{
		$this->load->view('header');
		$this->load->view('Appointment/appointmentbookinglist');
		$this->load->view('footer');
	}
	public function appointmentdashboard()
	{
		$this->load->view('header');
		$this->load->view('Appointment/appointmentdashboard');
		$this->load->view('footer');
	}
	public function createappointment()
	{
		$this->load->view('header');
		$this->load->view('Appointment/createappointment');
		$this->load->view('footer');
	}
	public function listvisits()
	{
		$this->load->view('header');
		$this->load->view('Appointment/listvisits');
		$this->load->view('footer');
	}
	public function phonebookappointment()
	{
		$this->load->view('header');
		$this->load->view('Appointment/phonebookappointment');
		$this->load->view('footer');
	}
	public function add_doctor()
	{
		$this->load->view('header');
		$this->load->view('Doctors/add_doctor');
		$this->load->view('footer');
	}
	public function all_doctors()
	{
		$this->load->view('header');
		$this->load->view('Doctors/all_doctors');
		$this->load->view('footer');
	}
	public function doctor_profile()
	{
		$this->load->view('header');
		$this->load->view('Doctors/doctor_profile');
		$this->load->view('footer');
	}
	public function profile_edit()
	{
		$this->load->view('header');
		$this->load->view('Doctors/profile_edit');
		$this->load->view('footer');
	}
	public function Ot()
	{
		$this->load->view('header');
		$this->load->view('OperationTheatre/Ot');
		$this->load->view('footer');
	}
	public function Newpatient()
	{
		$this->load->view('header');
		$this->load->view('Patient/Newpatient');
		$this->load->view('footer');
	}
	public function patientdashboard()
	{
		$this->load->view('header');
		$this->load->view('Patient/patientdashboard');
		$this->load->view('footer');
	}
	public function Emergencydashboard()
	{
		$this->load->view('header');
		$this->load->view('Emergency/Emergencydashboard');
		$this->load->view('footer');
	}
	public function Emg_new_patients()
	{
		$this->load->view('header');
		$this->load->view('Emergency/Emg_new_patients');
		$this->load->view('footer');
	}
	public function Emg_Triage_Patient()
	{
		$this->load->view('header');
		$this->load->view('Emergency/Emg_Triage_Patient');
		$this->load->view('footer');
	}
	public function Emp_Finalize_patient()
	{
		$this->load->view('header');
		$this->load->view('Emergency/Emp_Finalize_patient');
		$this->load->view('footer');
	}
	public function bedinformation()
	{
		$this->load->view('header');
		$this->load->view('bedinformation');
		$this->load->view('footer');
	}


    // help desk

    public function Helpdeskdashboard()
	{
		$this->load->view('header');
		$this->load->view('Helpdesk/Helpdeskdashboard');
		$this->load->view('footer');
	}
	public function EmployeesList()
	{
		$this->load->view('header');
		$this->load->view('Helpdesk/EmployeesList');
		$this->load->view('footer');
	}

     ///  Nursing

	public function Nursingdashboard()
	{
		$this->load->view('header');
		$this->load->view('Nursing/Nursingdashboard');
		$this->load->view('footer');
	}
	public function nursingnephrology()
	{
		$this->load->view('header');
		$this->load->view('Nursing/nursingnephrology');
		$this->load->view('footer');
	}
	public function nursingrequisition()
	{
		$this->load->view('header');
		$this->load->view('Nursing/nursingrequisition');
		$this->load->view('footer');
	}
	public function nursingdischarge()
	{
		$this->load->view('header');
		$this->load->view('Nursing/nursingdischarge');
		$this->load->view('footer');
	}

	public function nursinginpatient()
	{
		$this->load->view('header');
		$this->load->view('Nursing/nursinginpatient');
		$this->load->view('footer');
	}


	/// Labortary

	public function Laboratorydashboard()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/Laboratorydashboard');
		$this->load->view('footer');
	}


	/// OP Labortary

	public function Oplabdashboard()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/Oplabdashboard');
		$this->load->view('footer');
	}
		public function samplecollection()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/samplecollection');
		$this->load->view('footer');
	}
	public function addresult()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/addresult');
		$this->load->view('footer');
	}
	public function oplabfinalreport()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/oplabfinalreport');
		$this->load->view('footer');
	}
	public function oplabpendingreport()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/oplabpendingreport');
		$this->load->view('footer');
	}
	public function oplabsetting()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/oplabsetting');
		$this->load->view('footer');
	}
	public function oplabtest()
	{
		$this->load->view('header');
		$this->load->view('Laboratory/oplab/oplabtest');
		$this->load->view('footer');
	}




	///  Regidtration


	public function registration()
	{
		$this->load->view('registration');
	}
	
	
	
	
}
