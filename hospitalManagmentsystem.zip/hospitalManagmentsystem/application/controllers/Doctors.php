<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctors extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 * 	
	 */
	public function __construct()
	{
	        parent::__construct();
    	    $this->load->library(array('form_validation','session'));
        	$this->load->helper(array('url','html','form'));
        	$this->load->database();
        	$this->load->model('doctormodel');
    	}
	public function add_doctorcontroller()
	{
		$this->load->model('adminmodel');
		$doctorfname = $_POST['fname'];
		$doctorlname = $_POST['lname'];
		$doctorgender = $_POST['gender'];
		$doctorage    = $_POST['age'];
		$doctorqualification = $_POST['qualification'];
		$doctorspeciality = $_POST['speciality'];
		$doctoraddress1  = $_POST['address1'];
		$doctoraddress2  = $_POST['address2'];
		$doctorposition  = $_POST['position'];
		$doctordepartment = $_POST['department'];
		$doctorcreatedby = $_POST['createdby'];
		$doctoremail = $_POST['email'];
		$doctorcontactno = $_POST['phoneno'];
		$doctoralternative = $_POST['alphoneno'];
		$doctordate = $_POST['date'];
		$doctortime = $_POST['time'];
		$doctorpassword = $_POST['password'];


		$doctordata['doctor_firstname'] = $doctorfname;
		$doctordata['doctor_lastname'] = $doctorlname;
		$doctordata['doctor_gender'] = $doctorgender;
		$doctordata['doctor_age'] = $doctorage;
		$doctordata['doctor_email'] = $doctoremail;
		$doctordata['doctor_position'] = $doctorposition;
		$doctordata['doctor_qualification'] = $doctorqualification;

		$doctordata['doctor_speciality'] = $doctorspeciality;
		$doctordata['address1'] = $doctoraddress1;

		$doctordata['address2'] = $doctoraddress2;
		$doctordata['contactnumber'] = $doctorcontactno;
		$doctordata['alternativenumber'] = $doctoralternative;
		$doctordata['doctor_password'] = $doctorpassword;
		$doctordata['createdby'] = $doctorcreatedby;
		$doctordata['date'] =$doctordate;
		$doctordata['time'] = $doctortime;

		

		$response = $this->doctormodel->adddoctors($doctordata);
		if(!empty($response))
		{
			redirect('home');
		}
		else
		{
			redirect('error404');
		}
		
	}
	
	public function Login()
	{
		$this->load->model('adminmodel');
		$check_email = $_POST['email'];
		$check_password = $_POST['password'];
		$response =$this->adminmodel->superadminlogin($check_email,$check_password);
		if(!empty($response))
		{
			$this->session->set_userdata('superadminid', $response->superadminid);
			$this->session->set_userdata('superadminname', $response->superadminname);
			$this->session->set_userdata('superadminemail', $response->superadminemail);
			$this->session->set_userdata('superadminphoneno', $response->superadminphoneno);
			redirect('home');

		}
		else
		{
			$this->session->set_flashdata('error', 'Email or Password is not correct');
			redirect($_SERVER['HTTP_REFERER']);
		}


	}

	public function logout()
	{
		$this->session->unset_userdata('superadminid');
		$this->session->sess_destroy();
		redirect('/');
	}
}
