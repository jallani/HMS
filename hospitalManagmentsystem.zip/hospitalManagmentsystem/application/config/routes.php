<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['appointmentbookinglist']='home/appointmentbookinglist';
$route['appointmentdashboard'] ='home/appointmentdashboard';
$route['createappointment'] ='home/createappointment';
$route['listvisits'] ='home/listvisits';
$route['phonebookappointment'] ='home/phonebookappointment';
$route['add_doctor'] ='home/add_doctor';
$route['all_doctors'] ='home/all_doctors';
$route['doctor_profile'] ='home/doctor_profile';
$route['profile_edit'] ='home/profile_edit';
$route['Ot'] ='home/Ot';
$route['Newpatient'] ='home/Newpatient';
$route['patientdashboard'] ='home/patientdashboard';
$route['Emergencydashboard'] ='home/Emergencydashboard';
$route['Emg_new_patients'] ='home/Emg_new_patients';
$route['Emg_Triage_Patient'] ='home/Emg_Triage_Patient';
$route['Emp_Finalize_patient'] ='home/Emp_Finalize_patient';
$route['bedinformation'] ='home/bedinformation';


$route['Helpdeskdashboard'] ='home/Helpdeskdashboard';
$route['EmployeesList'] ='home/EmployeesList';



$route['Nursingdashboard'] ='home/Nursingdashboard';
$route['nursingnephrology'] ='home/nursingnephrology';
$route['nursingrequisition'] ='home/nursingrequisition';
$route['nursingdischarge'] ='home/nursingdischarge';
$route['nursinginpatient'] ='home/nursinginpatient';



$route['Laboratorydashboard'] ='home/Laboratorydashboard';

$route['Oplabdashboard'] ='home/Oplabdashboard';
$route['samplecollection'] ='home/samplecollection';
$route['addresult'] ='home/addresult';
$route['oplabfinalreport'] ='home/oplabfinalreport';
$route['oplabpendingreport'] ='home/oplabpendingreport';
$route['oplabsetting'] ='home/oplabsetting';
$route['oplabtest'] ='home/oplabtest';
$route['registration'] ='home/registration';
$route['home'] ='home/home';